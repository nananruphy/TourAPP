package com.example.tourdeakosombo;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

public class PagerAdapter extends FragmentStatePagerAdapter {

    int mNumOfTabs;
    public PagerAdapter(FragmentManager fm, int NumOfTabs) {
        super(fm);
        this.mNumOfTabs = NumOfTabs;
    }
    @Override
    public Fragment getItem(int position) {
        Fragment fragment = null;
        if (position == 0)
        {
            fragment = new History();
        }
        else if (position == 1)
        {
            fragment = new EthnicsGroup();
        }
        else if (position == 2)
        {
            fragment = new TourSites();
        }
        else if (position == 3)
        {
            fragment = new Hotels();
        }
        return fragment;
    }

    @Override
    public int getCount() {
        return 4;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        String title = null;
        if (position == 0)
        {
            title = "History";
        }
        else if (position == 1)
        {
            title = "Ethnics Group";
        }
        else if (position == 2)
        {
            title = "Tour Sites";
        }
        else if (position == 3)
        {
            title = "Hotels";
        }
        return title;
    }
}